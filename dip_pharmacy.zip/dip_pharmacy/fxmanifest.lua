fx_version 'bodacious'
game 'gta5'

author 'Dipzzy'
description 'pharmacy'
version '1.0.0'

this_is_a_map 'yes'